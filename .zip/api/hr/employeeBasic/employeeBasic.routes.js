const router = require("express").Router();

router.post("/getDesignationByEmpId", designationReports);
module.exports = router;