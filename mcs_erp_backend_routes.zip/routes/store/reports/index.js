const router = require("express").Router();
const {
  entriesProductReport,
  productStockStatus,
  productLogs,
  requisitionLogs,
  userRequisitionLogs,
  viewUserReqReport,
} = require("../../../controllers/store/reports");

const { checkBoth } = require("../../../middlewares/checkAuthorization");
const { validateToken } = require("../../../utils/JWT");

// get route
router.get("/entries", entriesProductReport);
router.get("/stockStatus", productStockStatus);
router.get("/productlogs", productLogs);
router.get("/requisitions", requisitionLogs);
router.get("/user/requisitions", userRequisitionLogs);
router.get("/user/:hrid/requisitions/:requestid", viewUserReqReport);

module.exports = router;
